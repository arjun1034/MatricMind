import requests
import sys
from pathlib import Path

print("🔥 MetricMind Filtered Semantic Agent")

BASE_DIR = Path(__file__).resolve().parent.parent

sys.path.append(str(BASE_DIR / "Data Engine"))
import query_engine

API_URL = "http://127.0.0.1:8000"


# --------------------------------------------------
# Get Semantic Layer
# --------------------------------------------------

def get_metrics():

    try:

        response = requests.get(f"{API_URL}/metrics")

        if response.status_code == 200:
            return response.json()

        return None

    except requests.exceptions.ConnectionError:

        return None


# --------------------------------------------------
# Dynamic Filters from Semantic Layer
# --------------------------------------------------

def get_filtered_data(question, metrics):

    df = query_engine.load_data()

    question = question.lower()

    dimensions = metrics.get("dimensions", [])

    filters = []

    for dimension in dimensions:

        column = dimension["column"]
        display_name = dimension["display_name"]

        if column not in df.columns:
            continue

        for value in df[column].dropna().unique():

            if str(value).lower() in question:

                df = df[
                    df[column].astype(str).str.lower()
                    == str(value).lower()
                ]

                filters.append(
                    f"{display_name}: {value}"
                )

                break

    if filters:

        return df, " | ".join(filters)

    return None, "All Data"


# --------------------------------------------------
# Advanced Business Questions
# --------------------------------------------------

def calculate_advanced_answer(question, df):

    question = question.lower()

    # ----------------------------------------------
    # Highest Revenue by Country
    # ----------------------------------------------

    if (
        "highest revenue" in question
        and "country" in question
    ):

        result = (
            df.groupby("Country")["Revenue"]
            .sum()
            .sort_values(ascending=False)
        )

        if result.empty:
            return "No country data found."

        country = result.index[0]
        revenue = result.iloc[0]

        return (
            f"Country with Highest Revenue: {country}\n"
            f"Revenue: {revenue:,.0f}"
        )

    # ----------------------------------------------
    # Lowest Revenue by Country
    # ----------------------------------------------

    if (
        "lowest revenue" in question
        and "country" in question
    ):

        result = (
            df.groupby("Country")["Revenue"]
            .sum()
            .sort_values(ascending=True)
        )

        if result.empty:
            return "No country data found."

        country = result.index[0]
        revenue = result.iloc[0]

        return (
            f"Country with Lowest Revenue: {country}\n"
            f"Revenue: {revenue:,.0f}"
        )

    # ----------------------------------------------
    # Highest Profit by Country
    # ----------------------------------------------

    if (
        "highest profit" in question
        and "country" in question
    ):

        result = (
            df.groupby("Country")["Profit"]
            .sum()
            .sort_values(ascending=False)
        )

        if result.empty:
            return "No country data found."

        country = result.index[0]
        profit = result.iloc[0]

        return (
            f"Country with Highest Profit: {country}\n"
            f"Profit: {profit:,.0f}"
        )

    # ----------------------------------------------
    # Lowest Profit by Country
    # ----------------------------------------------

    if (
        "lowest profit" in question
        and "country" in question
    ):

        result = (
            df.groupby("Country")["Profit"]
            .sum()
            .sort_values(ascending=True)
        )

        if result.empty:
            return "No country data found."

        country = result.index[0]
        profit = result.iloc[0]

        return (
            f"Country with Lowest Profit: {country}\n"
            f"Profit: {profit:,.0f}"
        )

    # ----------------------------------------------
    # Highest Revenue by Product
    # ----------------------------------------------

    if (
        "highest revenue" in question
        and "product" in question
    ):

        result = (
            df.groupby("Product")["Revenue"]
            .sum()
            .sort_values(ascending=False)
        )

        if result.empty:
            return "No product data found."

        product = result.index[0]
        revenue = result.iloc[0]

        return (
            f"Product with Highest Revenue: {product}\n"
            f"Revenue: {revenue:,.0f}"
        )

    # ----------------------------------------------
    # Highest Profit by Product
    # ----------------------------------------------

    if (
        "highest profit" in question
        and "product" in question
    ):

        result = (
            df.groupby("Product")["Profit"]
            .sum()
            .sort_values(ascending=False)
        )

        if result.empty:
            return "No product data found."

        product = result.index[0]
        profit = result.iloc[0]

        return (
            f"Product with Highest Profit: {product}\n"
            f"Profit: {profit:,.0f}"
        )

    return None


# --------------------------------------------------
# Normal Metric Calculation
# --------------------------------------------------

def calculate_answer(question, df, metrics):

    question = question.lower()

    for metric in metrics.get("metrics", []):

        name = metric["name"]
        display_name = metric["display_name"]

        # ------------------------------------------
        # Revenue
        # ------------------------------------------

        if name == "total_revenue" and (
            "revenue" in question
            or "sales" in question
            or "income" in question
            or "money" in question
            or "earn" in question
        ):

            value = query_engine.get_total_revenue(df)

            return (
                f"{display_name} is "
                f"{value:,.0f}"
            )

        # ------------------------------------------
        # Profit Margin
        # ------------------------------------------

        if name == "profit_margin" and (
            "profit margin" in question
            or "margin percentage" in question
            or "margin percent" in question
        ):

            revenue = query_engine.get_total_revenue(df)
            profit = query_engine.get_total_profit(df)

            value = (
                profit / revenue * 100
                if revenue else 0
            )

            return (
                f"{display_name} is "
                f"{value:.2f}%"
            )

        # ------------------------------------------
        # Profit
        # ------------------------------------------

        if name == "total_profit" and (
            "profit" in question
        ):

            value = query_engine.get_total_profit(df)

            return (
                f"{display_name} is "
                f"{value:,.0f}"
            )

        # ------------------------------------------
        # Churn Rate
        # ------------------------------------------

        if name == "churn_rate" and (
            "churn rate" in question
            or "churn percentage" in question
            or "churn percent" in question
        ):

            customers = (
                query_engine.get_total_customers(df)
            )

            churned = (
                query_engine
                .get_total_churned_customers(df)
            )

            value = (
                churned / customers * 100
                if customers else 0
            )

            return (
                f"{display_name} is "
                f"{value:.2f}%"
            )

        # ------------------------------------------
        # Churned Customers
        # ------------------------------------------

        if name == "total_churned_customers" and (
            "churned" in question
            or "customers left" in question
            or "users left" in question
            or "lost customers" in question
        ):

            value = (
                query_engine
                .get_total_churned_customers(df)
            )

            return (
                f"{display_name} are "
                f"{value:,.0f}"
            )

        # ------------------------------------------
        # Total Customers
        # ------------------------------------------

        if name == "total_customers" and (
            "customer" in question
            or "users" in question
        ):

            value = (
                query_engine
                .get_total_customers(df)
            )

            return (
                f"{display_name} are "
                f"{value:,.0f}"
            )

    return "Metric not identified."


# --------------------------------------------------
# Main Agent
# --------------------------------------------------

if __name__ == "__main__":

    metrics = get_metrics()

    if metrics:

        print("--------------------------------")
        print("API Connection: SUCCESS")
        print("Semantic Layer: CONNECTED")
        print("Data Engine: CONNECTED")
        print("Filters: ENABLED")
        print("Advanced Queries: ENABLED")
        print("--------------------------------")

        while True:

            question = input(
                "\nAsk your business question: "
            )

            if question.lower() in [
                "exit",
                "quit",
                "q"
            ]:

                print("Agent stopped.")
                break

            # --------------------------------------
            # Apply filters
            # --------------------------------------

            df, filter_info = get_filtered_data(
                question,
                metrics
            )

            if df is None:

                df = query_engine.load_data()

                filter_info = "All Data"

            # --------------------------------------
            # Advanced question first
            # --------------------------------------

            advanced_answer = (
                calculate_advanced_answer(
                    question,
                    df
                )
            )

            if advanced_answer:

                answer = advanced_answer

            else:

                answer = calculate_answer(
                    question,
                    df,
                    metrics
                )

            # --------------------------------------
            # Final Output
            # --------------------------------------

            print("\nFilter:", filter_info)

            print("Answer:", answer)

    else:

        print("API Connection: FAILED")