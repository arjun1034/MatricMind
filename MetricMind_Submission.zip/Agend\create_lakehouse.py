import pandas as pd
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

INPUT_FILE = BASE_DIR / "Dataset" / "MetricMind Business Data.xlsx"
OUTPUT_DIR = BASE_DIR / "Lakehouse" / "cleaned"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

OUTPUT_FILE = OUTPUT_DIR / "business_data.parquet"

print("Loading data...")
df = pd.read_excel(INPUT_FILE)

print(f"Rows loaded: {len(df)}")
print(f"Columns: {list(df.columns)}")

# Basic cleaning
df = df.drop_duplicates()
df = df.dropna(how="all")

# Convert Date
if "Date" in df.columns:
    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")

# Save cleaned data
df.to_parquet(OUTPUT_FILE, index=False)

print("✅ Lakehouse data created successfully!")
print(f"📁 Saved at: {OUTPUT_FILE}")
print(f"Rows after cleaning: {len(df)}")