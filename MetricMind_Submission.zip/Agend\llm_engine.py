import os
from dotenv import load_dotenv
from openai import OpenAI


load_dotenv()


class LLMEngine:

    def __init__(self):

        api_key = os.getenv(
            "OPENAI_API_KEY"
        )

        if not api_key:
            raise ValueError(
                "OPENAI_API_KEY not found in .env file."
            )

        self.client = OpenAI(
            api_key=api_key
        )

        self.model = "gpt-5.6-luna"

    def understand_question(self, question):

        prompt = f"""
You are the Natural Language Understanding
component of MetricMind, an Agentic Semantic BI Engine.

Understand the user's business question.

Do NOT calculate any values.

Return a concise interpretation of what
the user is asking.

User Question:
{question}
"""

        response = self.client.responses.create(
            model=self.model,
            input=prompt
        )

        return response.output_text


if __name__ == "__main__":

    print("🔥 MetricMind LLM Engine")
    print("----------------------------")

    llm = LLMEngine()

    question = input(
        "Enter business question: "
    )

    result = llm.understand_question(
        question
    )

    print("\nLLM Understanding:")
    print("----------------------------")
    print(result)