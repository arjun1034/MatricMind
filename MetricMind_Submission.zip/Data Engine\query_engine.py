import pandas as pd
from pathlib import Path


# --------------------------------------------------
# MetricMind Data Engine
# --------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent.parent

# Lakehouse cleaned data
DATA_FILE = BASE_DIR / "lakehouse" / "cleaned" / "business_data.parquet"


def load_data():
    """
    Load business data from the MetricMind Lakehouse.
    """
    if not DATA_FILE.exists():
        raise FileNotFoundError(
            f"Lakehouse data file not found: {DATA_FILE}"
        )

    return pd.read_parquet(DATA_FILE)


def get_total_revenue(df=None):
    if df is None:
        df = load_data()

    return df["Revenue"].sum()


def get_total_profit(df=None):
    if df is None:
        df = load_data()

    return df["Profit"].sum()


def get_total_customers(df=None):
    if df is None:
        df = load_data()

    return df["Customers"].sum()


def get_total_churned_customers(df=None):
    if df is None:
        df = load_data()

    return df["Churned_Customers"].sum()


def get_churn_rate(df=None):

    if df is None:
        df = load_data()

    customers = get_total_customers(df)
    churned = get_total_churned_customers(df)

    if customers == 0:
        return 0

    return churned / customers


def filter_data(column, value):

    df = load_data()

    if column not in df.columns:
        raise ValueError(
            f"Column '{column}' not found in business data."
        )

    filtered_df = df[
        df[column]
        .astype(str)
        .str.lower()
        == str(value).lower()
    ]

    return filtered_df


def get_highest_revenue_country():

    df = load_data()

    country_revenue = (
        df.groupby("Country")["Revenue"]
        .sum()
        .sort_values(ascending=False)
    )

    return country_revenue.index[0], country_revenue.iloc[0]


# --------------------------------------------------
# Test Data Engine
# --------------------------------------------------

if __name__ == "__main__":

    print("MetricMind Data Engine")
    print("----------------------")

    print("Data File:", DATA_FILE)
    print()

    df = load_data()

    print("Rows:", len(df))
    print("Columns:", list(df.columns))
    print()

    print("Total Revenue:", get_total_revenue())
    print("Total Profit:", get_total_profit())
    print("Total Customers:", get_total_customers())
    print("Total Churned Customers:", get_total_churned_customers())
    print("Churn Rate:", get_churn_rate())

    country, revenue = get_highest_revenue_country()

    print()
    print("Highest Revenue Country:", country)
    print("Country Revenue:", revenue)