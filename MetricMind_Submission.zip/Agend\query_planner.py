class QueryPlanner:

    def __init__(self, metrics):
        self.metrics = metrics

    # --------------------------------------------------
    # Detect Metric
    # --------------------------------------------------
    def detect_metric(self, question):

        question = question.lower().strip()

        # Specific metrics first
        # This prevents "profit margin" from being detected
        # as "total profit".

        metric_priority = [
            "profit_margin",
            "churn_rate",
            "total_churned_customers",
            "total_revenue",
            "total_profit",
            "total_customers"
        ]

        metric_map = {
            "profit_margin": [
                "profit margin",
                "margin percentage",
                "margin percent",
                "margin %"
            ],

            "churn_rate": [
                "churn rate",
                "churn percentage",
                "churn percent",
                "churn %"
            ],

            "total_churned_customers": [
                "churned customers",
                "customers churned",
                "customers left",
                "users left",
                "lost customers",
                "churned users"
            ],

            "total_revenue": [
                "revenue",
                "sales",
                "income",
                "money",
                "earnings",
                "earned"
            ],

            "total_profit": [
                "profit",
                "earning",
                "earn"
            ],

            "total_customers": [
                "customers",
                "customer",
                "users",
                "user"
            ]
        }

        for metric_name in metric_priority:

            keywords = metric_map.get(
                metric_name,
                []
            )

            for keyword in keywords:

                if keyword in question:

                    for metric in self.metrics.get(
                        "metrics",
                        []
                    ):

                        if metric["name"] == metric_name:

                            return {
                                "name": metric["name"],
                                "display_name":
                                    metric["display_name"],
                                "data_type":
                                    metric["data_type"]
                            }

        return None

    # --------------------------------------------------
    # Detect Dimension
    # --------------------------------------------------
    def detect_dimension(self, question):

        question = question.lower()

        detected = []

        for dimension in self.metrics.get(
            "dimensions",
            []
        ):

            name = dimension["name"]
            display_name = dimension["display_name"]

            if (
                name.lower() in question
                or display_name.lower() in question
            ):

                detected.append(
                    display_name
                )

        return detected

    # --------------------------------------------------
    # Detect Operation / Intent
    # --------------------------------------------------
    def detect_operation(self, question):

        question = question.lower()

        # Ranking / Highest
        if any(
            word in question
            for word in [
                "highest",
                "maximum",
                "max",
                "top"
            ]
        ):
            return "MAX"

        # Ranking / Lowest
        if any(
            word in question
            for word in [
                "lowest",
                "minimum",
                "min",
                "bottom"
            ]
        ):
            return "MIN"

        # Comparison
        if any(
            word in question
            for word in [
                "compare",
                "comparison",
                "comparative",
                "versus",
                "vs"
            ]
        ):
            return "COMPARE"

        # Average
        if any(
            word in question
            for word in [
                "average",
                "avg",
                "mean"
            ]
        ):
            return "AVERAGE"

        # Total / Sum
        if any(
            word in question
            for word in [
                "total",
                "sum",
                "how much",
                "how many",
                "what is",
                "show me"
            ]
        ):
            return "SUM"

        return "UNKNOWN"

    # --------------------------------------------------
    # Create Query Plan
    # --------------------------------------------------
    def create_plan(self, question):

        metric = self.detect_metric(
            question
        )

        dimensions = self.detect_dimension(
            question
        )

        operation = self.detect_operation(
            question
        )

        return {
            "question": question,
            "intent": operation,
            "metric": metric,
            "dimensions": dimensions
        }


# --------------------------------------------------
# Standalone Test
# --------------------------------------------------

if __name__ == "__main__":

    print(
        "🔥 MetricMind Query Planner"
    )

    print(
        "----------------------------"
    )

    import json
    from pathlib import Path

    BASE_DIR = (
        Path(__file__)
        .resolve()
        .parent
        .parent
    )

    METRICS_FILE = (
        BASE_DIR
        / "Semantic Layer"
        / "metrics.json"
    )

    with open(
        METRICS_FILE,
        "r",
        encoding="utf-8"
    ) as file:

        metrics = json.load(file)

    planner = QueryPlanner(
        metrics
    )

    while True:

        question = input(
            "\nEnter question: "
        )

        if question.lower() in [
            "exit",
            "quit",
            "q"
        ]:
            print("Planner stopped.")
            break

        plan = planner.create_plan(
            question
        )

        print("\nQuery Plan:")
        print("----------------------------")

        print(
            json.dumps(
                plan,
                indent=4
            )
        )