import json
from pathlib import Path

from query_planner import QueryPlanner
from execution_engine import ExecutionEngine


BASE_DIR = Path(__file__).resolve().parent.parent

METRICS_FILE = BASE_DIR / "Semantic Layer" / "metrics.json"


class MetricMindAgent:

    def __init__(self):

        # Load Semantic Layer
        with open(
            METRICS_FILE,
            "r",
            encoding="utf-8"
        ) as file:

            self.metrics = json.load(file)


        # Create Planner
        self.planner = QueryPlanner(
            self.metrics
        )


        # Create Execution Engine
        self.executor = ExecutionEngine(
            self.metrics
        )


    # --------------------------------------------------
    # Process User Question
    # --------------------------------------------------

    def ask(self, question):

        # Step 1: Create Query Plan
        plan = self.planner.create_plan(
            question
        )


        # Step 2: Execute Plan
        result = self.executor.execute(
            question,
            plan
        )


        # Step 3: Return complete response
        return {

            "question": question,

            "query_plan": plan,

            "result": result

        }


# --------------------------------------------------
# Test Agent
# --------------------------------------------------

if __name__ == "__main__":

    print("🔥 MetricMind Agent Core")
    print("----------------------------------------")


    agent = MetricMindAgent()


    while True:

        question = input(
            "\nAsk your business question: "
        )


        if question.lower() in [
            "exit",
            "quit",
            "q"
        ]:

            print("\nAgent stopped.")
            break


        response = agent.ask(
            question
        )


        print("\n🧠 QUERY PLAN")
        print("----------------------------------------")

        print(
            json.dumps(
                response["query_plan"],
                indent=4
            )
        )


        print("\n💡 RESULT")
        print("----------------------------------------")

        print(
            json.dumps(
                response["result"],
                indent=4
            )
        )