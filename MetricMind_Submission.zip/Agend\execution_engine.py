import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

sys.path.append(str(BASE_DIR / "Data Engine"))

import query_engine


class ExecutionEngine:

    def __init__(self, metrics):
        self.metrics = metrics

    # --------------------------------------------------
    # Apply Filters
    # --------------------------------------------------
    def apply_filters(self, question, df):

        question = question.lower()

        filters = []

        for dimension in self.metrics.get(
            "dimensions",
            []
        ):

            column = dimension["column"]
            display_name = dimension["display_name"]

            if column not in df.columns:
                continue

            for value in df[column].dropna().unique():

                if str(value).lower() in question:

                    df = df[
                        df[column]
                        .astype(str)
                        .str.lower()
                        == str(value).lower()
                    ]

                    filters.append(
                        f"{display_name}: {value}"
                    )

                    break

        if filters:
            return df, " | ".join(filters)

        return df, "All Data"

    # --------------------------------------------------
    # Metric Column Mapping
    # --------------------------------------------------
    def get_metric_column(self, metric_name):

        mapping = {
            "total_revenue": "Revenue",
            "total_profit": "Profit",
            "total_customers": "Customers",
            "total_churned_customers":
                "Churned_Customers"
        }

        return mapping.get(metric_name)

    # --------------------------------------------------
    # Aggregate
    # --------------------------------------------------
    def aggregate(
        self,
        df,
        metric_name,
        operation
    ):

        column = self.get_metric_column(
            metric_name
        )

        if column is None:
            return None

        if df.empty:
            return None

        if operation == "SUM":
            return df[column].sum()

        if operation == "AVERAGE":
            return df[column].mean()

        if operation == "MAX":
            return df[column].max()

        if operation == "MIN":
            return df[column].min()

        return None

    # --------------------------------------------------
    # Group Analysis
    # --------------------------------------------------
    def group_analysis(
        self,
        df,
        metric_name,
        dimension,
        operation
    ):

        column = self.get_metric_column(
            metric_name
        )

        if column is None:
            return None

        dimension_map = {
            "Country": "Country",
            "Product": "Product",
            "Region": "Region",
            "Category": "Category"
        }

        group_column = dimension_map.get(
            dimension
        )

        if group_column is None:
            return None

        if df.empty:
            return None

        if operation == "SUM":

            result = (
                df.groupby(group_column)[column]
                .sum()
                .sort_values(ascending=False)
            )

        elif operation == "AVERAGE":

            result = (
                df.groupby(group_column)[column]
                .mean()
                .sort_values(ascending=False)
            )

        elif operation == "MAX":

            result = (
                df.groupby(group_column)[column]
                .sum()
                .sort_values(ascending=False)
            )

        elif operation == "MIN":

            result = (
                df.groupby(group_column)[column]
                .sum()
                .sort_values(ascending=True)
            )

        else:
            return None

        return result

    # --------------------------------------------------
    # Compare
    # --------------------------------------------------
    def compare(
        self,
        df,
        metric_name,
        dimension
    ):

        return self.group_analysis(
            df,
            metric_name,
            dimension,
            "SUM"
        )

    # --------------------------------------------------
    # Execute Query
    # --------------------------------------------------
    def execute(
        self,
        question,
        plan
    ):

        df = query_engine.load_data()

        # Apply filters
        df, filter_info = self.apply_filters(
            question,
            df
        )

        metric = plan.get("metric")

        operation = plan.get("intent")

        dimensions = plan.get(
            "dimensions",
            []
        )

        # --------------------------------------------------
        # Metric validation
        # --------------------------------------------------

        if metric is None:

            return {
                "status": "error",
                "message":
                    "Metric not identified."
            }

        metric_name = metric["name"]

        # --------------------------------------------------
        # Derived Metrics
        # --------------------------------------------------

        if metric_name == "profit_margin":

            revenue = df["Revenue"].sum()

            profit = df["Profit"].sum()

            value = (
                profit / revenue * 100
                if revenue != 0
                else 0
            )

            return {
                "status": "success",
                "type": "metric",
                "metric":
                    metric["display_name"],
                "value":
                    round(value, 2),
                "filter":
                    filter_info
            }

        if metric_name == "churn_rate":

            customers = df["Customers"].sum()

            churned = df[
                "Churned_Customers"
            ].sum()

            value = (
                churned / customers * 100
                if customers != 0
                else 0
            )

            return {
                "status": "success",
                "type": "metric",
                "metric":
                    metric["display_name"],
                "value":
                    round(value, 2),
                "filter":
                    filter_info
            }

        # --------------------------------------------------
        # Ranking
        # --------------------------------------------------

        if (
            operation in ["MAX", "MIN"]
            and dimensions
        ):

            dimension = dimensions[0]

            result = self.group_analysis(
                df,
                metric_name,
                dimension,
                operation
            )

            if (
                result is None
                or result.empty
            ):

                return {
                    "status": "error",
                    "message":
                        "No data found."
                }

            item = result.index[0]

            value = result.iloc[0]

            return {
                "status": "success",
                "type": "ranking",
                "metric":
                    metric["display_name"],
                "dimension":
                    dimension,
                "operation":
                    operation,
                "result":
                    str(item),
                "value":
                    round(float(value), 2),
                "filter":
                    filter_info
            }

        # --------------------------------------------------
        # Compare
        # --------------------------------------------------

        if (
            operation == "COMPARE"
            and dimensions
        ):

            dimension = dimensions[0]

            result = self.compare(
                df,
                metric_name,
                dimension
            )

            if (
                result is None
                or result.empty
            ):

                return {
                    "status": "error",
                    "message":
                        "No comparison data found."
                }

            comparison = {}

            for item, value in result.items():

                comparison[str(item)] = round(
                    float(value),
                    2
                )

            return {
                "status": "success",
                "type": "comparison",
                "metric":
                    metric["display_name"],
                "dimension":
                    dimension,
                "values":
                    comparison,
                "filter":
                    filter_info
            }

        # --------------------------------------------------
        # Average with Dimension
        # --------------------------------------------------

        if (
            operation == "AVERAGE"
            and dimensions
        ):

            dimension = dimensions[0]

            result = self.group_analysis(
                df,
                metric_name,
                dimension,
                "AVERAGE"
            )

            if (
                result is None
                or result.empty
            ):

                return {
                    "status": "error",
                    "message":
                        "Unable to calculate average."
                }

            values = {}

            for item, value in result.items():

                values[str(item)] = round(
                    float(value),
                    2
                )

            return {
                "status": "success",
                "type": "average_comparison",
                "metric":
                    metric["display_name"],
                "dimension":
                    dimension,
                "values":
                    values,
                "filter":
                    filter_info
            }

        # --------------------------------------------------
        # Global Average
        # --------------------------------------------------

        if operation == "AVERAGE":

            value = self.aggregate(
                df,
                metric_name,
                "AVERAGE"
            )

            if value is None:

                return {
                    "status": "error",
                    "message":
                        "Unable to calculate average."
                }

            return {
                "status": "success",
                "type": "average",
                "metric":
                    metric["display_name"],
                "value":
                    round(float(value), 2),
                "filter":
                    filter_info
            }

        # --------------------------------------------------
        # Default SUM
        # --------------------------------------------------

        value = self.aggregate(
            df,
            metric_name,
            "SUM"
        )

        if value is None:

            return {
                "status": "error",
                "message":
                    "Unable to calculate metric."
            }

        return {
            "status": "success",
            "type": "metric",
            "metric":
                metric["display_name"],
            "value":
                round(float(value), 2),
            "filter":
                filter_info
        }