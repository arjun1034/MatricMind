from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import sys
from pathlib import Path

# --------------------------------------------------
# PATH SETUP
# --------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent.parent
AGENT_DIR = BASE_DIR / "Agend"

sys.path.append(str(AGENT_DIR))

from agent_core import MetricMindAgent


# --------------------------------------------------
# FASTAPI
# --------------------------------------------------

app = FastAPI(
    title="MetricMind API",
    description="Agentic Semantic BI Engine",
    version="1.0.0"
)


# --------------------------------------------------
# CORS
# --------------------------------------------------

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# --------------------------------------------------
# AGENT
# --------------------------------------------------

agent = MetricMindAgent()


# --------------------------------------------------
# REQUEST MODEL
# --------------------------------------------------

class QuestionRequest(BaseModel):
    question: str


# --------------------------------------------------
# ROOT
# --------------------------------------------------

@app.get("/")
def root():
    return {
        "project": "MetricMind",
        "status": "running",
        "message": "MetricMind API is working"
    }


# --------------------------------------------------
# HEALTH
# --------------------------------------------------

@app.get("/health")
def health():
    return {
        "status": "healthy",
        "engine": "MetricMind Agent"
    }


# --------------------------------------------------
# ASK
# --------------------------------------------------

@app.post("/ask")
def ask_question(request: QuestionRequest):

    response = agent.ask(request.question)

    return response