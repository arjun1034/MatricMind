# MetricMind – Agentic Semantic BI Engine

## Project Overview

MetricMind is an AI-powered Business Intelligence project that uses a governed Semantic Layer to answer business questions using defined metrics and business data.

## Project Structure

* Agend – Agent and query planning components
* API – FastAPI application
* Chat UI – Web interface
* Data Engine – Data query engine
* Dataset – Original business dataset
* Lakehouse – Cleaned business data
* Semantic Layer – Metrics, dimensions, and business rules

## Technologies

* Python
* FastAPI
* Pandas
* Parquet
* HTML
* JSON

## Setup

1. Install Python.

2. Install the required dependencies using `pip install -r requirements.txt`.

3. Configure the required environment variables securely.

4. Run the API using the command below from the project root:

   `uvicorn API.main:app --reload`

5. Open `http://127.0.0.1:8000` to check the API.

## Security

Do not share API keys, passwords, or secret environment variables in the submission ZIP.
