import sys
import json
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

sys.path.append(str(BASE_DIR / "Data Engine"))

import query_engine
from query_planner import QueryPlanner


print("🔥 MetricMind Intelligent Execution Engine")
print("----------------------------------------")


# --------------------------------------------------
# Load Semantic Layer
# --------------------------------------------------

METRICS_FILE = BASE_DIR / "Semantic Layer" / "metrics.json"

with open(
    METRICS_FILE,
    "r",
    encoding="utf-8"
) as file:

    metrics = json.load(file)


planner = QueryPlanner(metrics)


# --------------------------------------------------
# Detect Filters
# --------------------------------------------------

def apply_filters(question, df):

    question_lower = question.lower()

    filters = []

    for dimension in metrics.get("dimensions", []):

        column = dimension["column"]
        display_name = dimension["display_name"]

        if column not in df.columns:
            continue

        for value in df[column].dropna().unique():

            if str(value).lower() in question_lower:

                df = df[
                    df[column]
                    .astype(str)
                    .str.lower()
                    == str(value).lower()
                ]

                filters.append(
                    f"{display_name}: {value}"
                )

                break

    if filters:

        return df, " | ".join(filters)

    return df, "All Data"


# --------------------------------------------------
# Execute Query
# --------------------------------------------------

def execute_query(question):

    df = query_engine.load_data()

    # Apply filters first
    df, filter_info = apply_filters(
        question,
        df
    )

    # Create query plan
    plan = planner.create_plan(question)

    metric = plan["metric"]
    intent = plan["intent"]
    dimensions = plan["dimensions"]


    print("\n🧠 QUERY PLAN")
    print("----------------------------------------")
    print("Intent     :", intent)
    print("Metric     :", metric)
    print("Dimensions :", dimensions)
    print("Filters    :", filter_info)


    if metric is None:

        return "Metric not identified."


    metric_name = metric["name"]


    # --------------------------------------------------
    # MAX / MIN with Dimension
    # --------------------------------------------------

    if intent in ["MAX", "MIN"] and dimensions:

        dimension = dimensions[0]

        column_map = {
            "Country": "Country",
            "Product": "Product",
            "Region": "Region",
            "Category": "Category"
        }

        column = column_map.get(dimension)

        if not column:

            return "Unsupported dimension."


        # Select metric column
        if metric_name == "total_revenue":

            value_column = "Revenue"

        elif metric_name == "total_profit":

            value_column = "Profit"

        else:

            return (
                "Ranking currently supports "
                "Revenue and Profit."
            )


        result = (
            df.groupby(column)[value_column]
            .sum()
        )


        if intent == "MAX":

            result = result.sort_values(
                ascending=False
            )

        else:

            result = result.sort_values(
                ascending=True
            )


        if result.empty:

            return "No data found."


        item = result.index[0]
        value = result.iloc[0]


        operation = (
            "Highest"
            if intent == "MAX"
            else "Lowest"
        )


        return (
            f"{operation} "
            f"{metric['display_name']} by "
            f"{dimension}: {item}\n"
            f"{metric['display_name']}: "
            f"{value:,.0f}"
        )


    # --------------------------------------------------
    # Total Revenue
    # --------------------------------------------------

    if metric_name == "total_revenue":

        value = query_engine.get_total_revenue(df)

        return (
            f"Total Revenue: "
            f"{value:,.0f}"
        )


    # --------------------------------------------------
    # Total Profit
    # --------------------------------------------------

    if metric_name == "total_profit":

        value = query_engine.get_total_profit(df)

        return (
            f"Total Profit: "
            f"{value:,.0f}"
        )


    # --------------------------------------------------
    # Total Customers
    # --------------------------------------------------

    if metric_name == "total_customers":

        value = query_engine.get_total_customers(df)

        return (
            f"Total Customers: "
            f"{value:,.0f}"
        )


    # --------------------------------------------------
    # Churned Customers
    # --------------------------------------------------

    if metric_name == "total_churned_customers":

        value = (
            query_engine
            .get_total_churned_customers(df)
        )

        return (
            f"Total Churned Customers: "
            f"{value:,.0f}"
        )


    # --------------------------------------------------
    # Profit Margin
    # --------------------------------------------------

    if metric_name == "profit_margin":

        revenue = query_engine.get_total_revenue(df)

        profit = query_engine.get_total_profit(df)

        value = (
            profit / revenue * 100
            if revenue else 0
        )

        return (
            f"Profit Margin: "
            f"{value:.2f}%"
        )


    # --------------------------------------------------
    # Churn Rate
    # --------------------------------------------------

    if metric_name == "churn_rate":

        customers = (
            query_engine
            .get_total_customers(df)
        )

        churned = (
            query_engine
            .get_total_churned_customers(df)
        )

        value = (
            churned / customers * 100
            if customers else 0
        )

        return (
            f"Churn Rate: "
            f"{value:.2f}%"
        )


    return "Query execution not supported yet."


# --------------------------------------------------
# Main Loop
# --------------------------------------------------

while True:

    question = input(
        "\nAsk your business question: "
    )


    if question.lower() in [
        "exit",
        "quit",
        "q"
    ]:

        print("\nAgent stopped.")
        break


    answer = execute_query(question)


    print("\n💡 ANSWER")
    print("----------------------------------------")
    print(answer)